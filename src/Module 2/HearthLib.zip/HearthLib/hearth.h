#ifndef _HEATH
#define _HEATH

void mod1();
void mod2();
void mod3();
void mod4();

#endif
