#include "hearth.h"

void mod1() {
for(int i=2; i<=11; i++){
digitalWrite(i, HIGH); 
delay(1000); 
digitalWrite(i, LOW); 
delay(20);  
 }
}

void mod2() {
for (int i=2; i<=11; i+=2){
digitalWrite(i, HIGH); 
delay(1000); 
digitalWrite(i, LOW); 
delay(20);  
 } 
}

void mod3() {
for (int i=2; i<=11; i++){
  if (i%2==0) {
    digitalWrite (i, HIGH);
    }
  }
 delay (2000);
for (int i=2; i<=11; i++){
  if (i%2==0) {
    digitalWrite (i, LOW);
    delay(99);
    }
} 
}

void mod4(){
for(int i=2; i<=11; i++){
digitalWrite(i, HIGH);
delay (100);  
}
for(int i=2; i<=11; i++){
 digitalWrite(i, LOW);  
 delay(50);
}
}
